# TjasaPeter

## Tjaša

Je danes sama.

## Peter

Je danes bolan doma.

## Plan

* Dobiš podatke od nekje,
* pripraviš bazo,
* v aplikaciji pokažeš nekaj.

[ER diagam](ER diagram.png)
