db = 'sem2018_tjasab'
host = 'baza.fmf.uni-lj.si'
user = 'javnost'
password = 'javnogeslo'
